package br.com.senac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
